"""
Code generation and testing environment using LLMs.
"""
